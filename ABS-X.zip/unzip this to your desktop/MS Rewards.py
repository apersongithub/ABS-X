from selenium import webdriver

web = webdriver.Chrome()
web.get('https://google.com/')